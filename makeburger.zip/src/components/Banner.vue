<template>
  <div id="main-banner" style="background-image: url('/img/burger.jpg');">
    <h1>Make your Burger</h1>
    <!-- <img src="/img/burger.jpg" alt="a"> -->
  </div>
</template>

<script>
export default {
  name: "Banner",
//   imgurl: '/img/burger.jpg'
};
</script>

<style scoped>
 #main-banner {
    background-position: 0 -250px;
    background-size: cover;
    height: 500px;
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }

  #main-banner h1 {
    color: #FFF;
    text-align: center;
    font-size: 60px;
    background-color: #222;
    padding: 20px 40px;
  }
</style>