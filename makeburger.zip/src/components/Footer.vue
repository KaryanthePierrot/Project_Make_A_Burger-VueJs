<template>
  <footer id="footer">
    <p>Make your Burger &copy; 2025</p>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
#footer {
  margin-top: 25px;
  height: 100px;
  background-color: #222;
  border-top: 4px solid #111;
  color: #fcba03;
  display: flex;
  position: absolute bottom;
  align-items: center;
  justify-content: center;
  bottom: 0 ;
  width: 100%;
}
</style>